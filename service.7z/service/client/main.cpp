#include <common/common.h>
int main(int argc, char* argv[])
{
	auto info_logger = [](const std::string& msg) { std::cout << msg << std::endl; };

	itc::init_data init;
	init.log_info = info_logger;
	init.log_error = info_logger;
	itc::init(init);
	net::set_logger(info_logger);
	net::init_services();

	try
	{
        auto connector = net::create_tcp_client("::1", 11111);
        net::set_builder(connector);

        auto net = net::json_net();

        net->add_connector(std::move(connector),
        [](net::connection::id_t id)
        {
            net::log() << "Connected.";


            net::json msg;
            msg["id"] = "request_tags";

            auto net = net::json_net();
            net->send_msg(id, std::move(msg));
        },
        [](net::connection::id_t id, const net::error_code& ec)
        {
            net::log() << "Disconnected. Reason : " << ec.message();
        },
        [](net::connection::id_t id, net::json msg)
        {
            std::string msg_id{};
            if(!net::get_msg_id(msg, msg_id))
            {
                net::log() << "Recieved invalid msg :\n"
                           << std::setw(4) << msg;
                return;
            }
            net::log() << "Recieved msg :\n"
                       << std::setw(4) << msg;

            if(msg_id == "tags")
            {
                std::vector<std::string> tags = msg["tags"];
                for(const auto& tag : tags)
                {
                    net::log() << tag;
                }

                net::json msg;
                msg["id"] = "request_settings";

                auto net = net::json_net();
                net->send_msg(id, std::move(msg));
            }
        });
	}
	catch(std::exception& e)
	{
        net::log() << "Exception: " << e.what();
	}

    while(!itc::this_thread::notified_for_exit())
    {
        itc::this_thread::process();
    }

	net::deinit_messengers();
	net::deinit_services();
	return itc::shutdown();
}
