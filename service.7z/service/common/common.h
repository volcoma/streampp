#pragma once
#include <asiopp/service.h>
#include <builderpp/msg_builder.h>
#include <messengerpp/messenger.h>
#include <jsonpp/json.hpp>
#include <sstream>
#include <iomanip>

namespace net
{
struct tag_stream
{
};

using json = nlohmann::json;

template <>
struct serializer<json, tag_stream, tag_stream>
{
	static byte_buffer to_buffer(const json& msg)
	{
		return json::to_msgpack(msg);
	}
	static json from_buffer(byte_buffer&& buffer)
	{
		return json::from_msgpack(buffer);
	}
};

void set_builder(net::connector_ptr& connector);
inline auto json_net()
{
	return get_messenger<json, tag_stream, tag_stream>();
}

bool get_msg_id(const json& msg, std::string& id);
}
