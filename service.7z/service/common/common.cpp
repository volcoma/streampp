#include "common.h"

namespace net
{

void set_builder(net::connector_ptr& connector)
{
	if(connector)
	{
		connector->create_builder = net::msg_builder::get_creator<net::single_buffer_builder>();
	}
}

bool get_msg_id(const json& msg, std::string& id)
{
	try
	{
		id = msg.at("id");
	}
	catch(const std::exception& e)
	{
		net::log() << e.what();
		return false;
	}

    return true;
}
}
