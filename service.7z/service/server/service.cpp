#include "service.h"
#include <common/common.h>
#include <gitpp/repository.hpp>
namespace test
{
void service::init(uint16_t port)
{

	auto connector = net::create_tcp_server(port);
	net::set_builder(connector);
	auto net = net::json_net();

	net->add_connector(std::move(connector),
					   [](net::connection::id_t id) {
						   net::log() << "Connected client " << id;

					   },
					   [](net::connection::id_t id, const net::error_code& ec) {
						   net::log() << "Disconnected client " << id << ". Reason : " << ec.message();

					   },
					   [this](net::connection::id_t id, net::json msg) {
						   std::string msg_id{};
						   if(!net::get_msg_id(msg, msg_id))
						   {
							   net::log() << "Recieved invalid msg from client " << id << " :\n"
										  << std::setw(4) << msg;
							   return;
						   }
						   net::log() << "Recieved msg from client " << id << " :\n" << std::setw(4) << msg;

						   if(msg_id == "request_tags")
						   {
							   on_tags_requested(id, msg);
						   }
						   else if(msg_id == "request_settings")
						   {
							   on_settings_requested(id, msg);
						   }

					   });
}

void service::shutdown()
{
	pool_.stop_all();
	pool_.wait_all();
}

void service::on_tags_requested(net::connection::id_t id, const net::json&)
{
	pool_.schedule([id]() {
		auto tags = git::remote::get_tags("some remote", "some user", "some pass");
		std::vector<std::string> tag_names;
		tag_names.reserve(tags.size());
		for(const auto& tag : tags)
		{
			tag_names.emplace_back(tag.name);
		}
		net::json msg;
		msg["id"] = "tags";
		msg["tags"] = std::move(tag_names);

		auto net = net::json_net();
		net->send_msg(id, std::move(msg));
	});
}

void service::on_settings_requested(net::connection::id_t id, const net::json&)
{
	pool_.schedule([id]() {
		net::json settings = {

			{"currency", "USD"},
            {"denominations", {0.1, 0.2, 0.3}}

		};

		net::json msg;
		msg["id"] = "settings";
		msg["settings"] = std::move(settings);

		auto net = net::json_net();
		net->send_msg(id, std::move(msg));
	});
}
}
