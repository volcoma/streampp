#include <common/common.h>
#include <itc/thread_pool.h>

namespace test
{

class service
{
public:
    void init(uint16_t port);
    void shutdown();

    void on_tags_requested(net::connection::id_t id, const net::json& msg);
    void on_settings_requested(net::connection::id_t id, const net::json& msg);

private:
    itc::thread_pool pool_;
};

}
