#include "service.h"

int main(int argc, char* argv[])
{

    try
	{
        auto info_logger = [](const std::string& msg) { std::cout << msg << std::endl; };

        itc::init_data init;
        init.log_info = info_logger;
        init.log_error = info_logger;
        itc::init(init);
        net::set_logger(info_logger);
        net::init_services();

        test::service service;
        service.init(11111);

        while(!itc::this_thread::notified_for_exit())
        {
            itc::this_thread::wait();
        }

        service.shutdown();

        net::deinit_messengers();
        net::deinit_services();
        return itc::shutdown();

    }
	catch(std::exception& e)
	{
		net::log() << "Exception: " << e.what();
	}
}
